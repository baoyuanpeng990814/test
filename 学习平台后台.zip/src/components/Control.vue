<template>
  <el-container>
    <el-header class="control_header" height="48px">
      <el-row>
        <el-col :span="10">
          <el-image style="width: 180px; height: 48px" :src="require('../images/logo3.png')" alt="" fit="fit">
          </el-image>
        </el-col>
        <el-col :span="18">
          <el-menu class="el-menu-demo" mode="horizontal" background-color="#068FCD" text-color="#fff"
            active-text-color="#ffffff" unique-opened router>
            <el-menu-item v-for="d in dataList" :index="d.fireUrl">{{d.menuName}}</el-menu-item>
          </el-menu>
        </el-col>
      </el-row>
    </el-header>
    <router-view></router-view>
  </el-container>
</template>

<script>
  import BroadCast from '../api/broadcast.js'
  export default {
    data() {
      return {
        userinfo: null,
        dataList: []
      }
    },
    created() {
      this.userinfo = this.$store.getters.userinfo
      if (this.userinfo.userId == null) { //获取用户信息
        this.$store.commit("updateUserInfo", JSON.parse(document.cookie))
        this.userinfo = this.$store.getters.userinfo
      }
      this.dataList = this.$store.getters.role
      if (this.dataList[0] == null) {
        this.getMenu()
      }
    },
    methods: {
      async getMenu() { //获取菜单，（如果后台设置了修改了菜单树，需修改route文件）
        const {
          data: res
        } = await this.$http.get("/manager/item/tree?roleId=" + this.userinfo.roleId)
        if (res.state !== 200) {
          //return this.$message.error('数据获取失败！')
          this.dataList = []
        } else {
          this.dataList = res.data
          this.$store.commit("updateRole", this.dataList)
          this.$forceUpdate()
          BroadCast.$emit("getRoleDone")
          if (res.data.count == 0) {
            this.$router.push('/')
          } else {
            this.$forceUpdate()
            // this.$router.push(res.data[0].chilLItem[0].fireUrl)
          }
        }
      }
    },
  }
</script>

<style scoped>
  .el-container .el-header {
    padding: 0;
  }

  .side_menu .el-menu {
    border: none;
  }

  .side_menu .el-menu .el-menu-item {
    text-align: center;
  }

  .side_menu .el-menu .el-menu-item i {
    color: white;
  }

  .el-col {
    width: auto;
  }

  .el-aside {
    background-color: #333744;
  }

  .unfold {
    padding: 8px 10px;
    text-align: right;
    background-color: rgb(103, 106, 108)
  }

  .el-avatar {
    margin: 10px 0 10px 12px;
  }
</style>
