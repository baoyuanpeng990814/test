<template>
  <div id="app">
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/examanalyzation' }">考试统计</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/examanalyzationdetail' }">考试统计详情</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="card_detail">
      <el-card>
        <div slot="header" class="clearfix">
          <el-row>
            <el-col :span="20">
              <el-button @click="basicInfo">基本信息</el-button>
              <el-button @click="stateInfo">整体分析</el-button>
              <el-button @click="scoreInfo">成绩统计</el-button>
              <el-button @click="scoreTable">成绩报表</el-button>
            </el-col>
            <el-col :span="4">
              <el-button icon="el-icon-arrow-left" @click="$router.go(-1)">返回</el-button>
            </el-col>
          </el-row>
        </div>
        <div class="detail_lines">
          <el-container>
            <el-main v-if="showExaminfo">
              <el-row>
                <el-col :span="4">
                  基本信息
                </el-col>
                <el-col :span="20">
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  试卷名称
                </el-col>
                <el-col :span="20">
                  {{examInfo.examName}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  主办单位
                </el-col>
                <el-col :span="20">
                  {{examInfo.organizationName}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  负责人
                </el-col>
                <el-col :span="20">
                  {{examInfo.createUser}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  发布时间
                </el-col>
                <el-col :span="20">
                  {{examInfo.releaseTime|transfermDate}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  失效时间
                </el-col>
                <el-col :span="20">
                  {{examInfo.failureTime|transfermDate}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  归档方式
                </el-col>
                <el-col :span="20">
                  {{examInfo.examFile | transfermExamFile}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  计时选项
                </el-col>
                <el-col :span="20">
                  <div v-if="examInfo.timingType=='1'">
                    考试时长：{{examInfo.timingStartTime}}
                  </div>
                  <div v-if="examInfo.timingType=='2'">
                    开考时间：{{examInfo.timingStartTime}}
                    结束时间：{{examInfo.timingEndTime}}
                  </div>

                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  归档方式
                </el-col>
                <el-col :span="20">
                  {{examInfo.achievementType | transfermAchievementType}}
                </el-col>
              </el-row>

              <el-row>
                <el-col :span="4">
                  出题方式
                </el-col>
                <el-col :span="20">
                  {{examInfo.assignTopic | transfermAssignTopic}}
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="4">
                  分数设置
                </el-col>
                <el-col :span="20">
                  {{examInfo.fractionType | transfermFractionType}}
                </el-col>
              </el-row>

            </el-main>


            <el-main v-if="showStatistic">
              <div class="statistic_table">
                <table>
                  <tr>
                    <td>应考人数</td>
                    <td>{{this.chartData.enrollNum}}</td>
                    <td>实考人数</td>
                    <td>{{this.chartData.examNum}}</td>
                    <td>通过人数</td>
                    <td>{{this.chartData.completeNum}}</td>

                  </tr>
                  <tr>
                    <td>及格分</td>
                    <td>{{this.chartData.passingMark}}</td>
                    <td>最高分</td>
                    <td>{{this.chartData.maxScores}}</td>
                    <td>最低分</td>
                    <td>{{this.chartData.minScores}}</td>

                  </tr>
                </table>
              </div>

              <div class="statistic_div">
                <div>
                  <el-table height=" calc(100vh - 350px) " ref="multipleTable" :data="datatable" tooltip-effect="dark"
                    style="width: 100%">
                    <el-table-column prop="score" label="分数段" width="70">
                    </el-table-column>
                    <el-table-column prop="num" label="人数" width="60">
                    </el-table-column>
                  </el-table>
                </div>
                <div>
                  <ExamState :data="option"></ExamState>
                </div>
                <div class="cb"></div>
              </div>
            </el-main>
            <el-main v-if="showScore">
              <CandidateScore :option="option2"></CandidateScore>
            </el-main>
            <el-main v-if="showTable">
              <el-button @click="exportExcel()">点击导出当前列表的excel</el-button>
              <el-table  height=" calc(100vh - 350px) " ref="multipleTable" :data="examUserList" tooltip-effect="dark" style="width: 100%"
                @selection-change="handleSelectionChange" id="out-table">
                <el-table-column type="selection" width="55">
                </el-table-column>
                <el-table-column prop="userId" label="序号" width="50">
                </el-table-column>
                <el-table-column prop="userName" label="用户名" width="200">
                </el-table-column>
                <el-table-column prop="userScore" label="用户成绩" width="200">
                </el-table-column>


              </el-table>
            </el-main>
          </el-container>

        </div>
      </el-card>
    </div>

  </div>
</template>

<script>
  import ExamState from '../panel/ExamState.vue'
  import CandidateScore from '../charts/CandidateScore.vue'
  import FileSaver from "file-saver";
  import XLSX from "xlsx";
  export default {
    components: {
      ExamState,
      CandidateScore
    },
    data() {
      return {
        examInfo: {},
        showExaminfo: true,
        showStatistic: false,
        showScore: false,
        showTable: false,
        datadetail: {},
        examUserList : "",
        chartData: [],
        option: {
          xAxis: {
            type: 'category',
            data: []
          },
          yAxis: {
            type: 'value'
          },
          series: [{
            type: 'bar',
            data: [],
          }],

        },
        datatable: [],
        option2: {
          yAxis: {
            type: 'category',
            data: []
          },
          xAxis: {
            type: 'value'
          },
          series: [{
            data: [],
            type: 'bar',
            name: '分数'
          }],
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'shadow'
            }
          },
          grid: {
            containLabel: true

          }
        },
        barchart:{}
      }
    },
    created() {
      this.datadetail = this.$route.query

      this.getExamInfo()
      this.getExamReport()
    },
    mounted() {


    },
    methods: {
      basicInfo() {
        this.showScore = false
        this.showStatistic = false
        this.showExaminfo = true
        this.showTable = false
      },
      stateInfo() {
        this.showStatistic = true
        this.showExaminfo = false
        this.showScore = false
        this.showTable = false
      },
      scoreInfo() {
        this.showStatistic = false
        this.showExaminfo = false
        this.showScore = true
        this.showTable = false
      },
      scoreTable() {
        this.showStatistic = false
        this.showExaminfo = false
        this.showScore = false
        this.showTable = true
      },
      async getExamReport() {
        const {
          data: res
        } = await this.$http.post("/manager/lStatistic/examReport", {
          id: this.datadetail.examId,
          num: 1
        })
        if (res.state !== 200) {
          this.chartData = []
          return this.$message.error('操作失败！')
        } else {
          this.chartData = res.data
          this.examUserList = res.data.examUserList;
          for (var i = 0; i < res.data.examUserList.length; i++) {
            this.option2.series[0].data.push( res.data.examUserList[i].userScore)
            this.option2.yAxis.data.push(res.data.examUserList[i].userName)
          }



          this.option.xAxis.data = ["0-9", "10-19", "20-29", "30-39", "40-49", "50-59",
            "60-69", "70-79", "80-89", "90-100"
          ]
          for (var i = 0; i < this.option.xAxis.data.length; i++) {
            this.option.series[0].data.push(this.chartData.reportList[0][this.option.xAxis.data[i]])

          }
          this.datatable.push({
            score: "0-9",
            num: this.chartData.reportList[0]["0-9"]
          })
          this.datatable.push({
            score: "10-19",
            num: this.chartData.reportList[0]["10-19"]
          })
          this.datatable.push({
            score: "20-29",
            num: this.chartData.reportList[0]["20-29"]
          })
          this.datatable.push({
            score: "30-39",
            num: this.chartData.reportList[0]["30-39"]
          })
          this.datatable.push({
            score: "40-49",
            num: this.chartData.reportList[0]["40-49"]
          })
          this.datatable.push({
            score: "50-59",
            num: this.chartData.reportList[0]["50-59"]
          })
          this.datatable.push({
            score: "60-69",
            num: this.chartData.reportList[0]["60-69"]
          })
          this.datatable.push({
            score: "70-79",
            num: this.chartData.reportList[0]["70-79"]
          })
          this.datatable.push({
            score: "80-89",
            num: this.chartData.reportList[0]["80-89"]
          })
          this.datatable.push({
            score: "90-100",
            num: this.chartData.reportList[0]["90-100"]
          })


        }
      },
      async getExamInfo() {
        const {
          data: res
        } = await this.$http.post("/manager/lStatistic/examInfo", {
          id: this.datadetail.examId
        })
        if (res.state !== 200) {
          this.tableData = []
          return this.$message.error('操作失败！')
        } else {
          this.examInfo = res.data
          //console.log(this.examInfo)
          //console.log(res)
          //return this.$message.success('操作成功！')

        }
      },
      //定义导出Excel表格事件
      exportExcel() {

        /* 从表生成工作簿对象 */
        let wb = XLSX.utils.table_to_book(document.querySelector('#out-table'))
        /* 获取二进制字符串作为输出 */
        var wbout = XLSX.write(wb, {
          bookType: 'xlsx',
          bookSST: true,
          type: 'array'
        })
        try {
          FileSaver.saveAs(
            //Blob 对象表示一个不可变、原始数据的类文件对象。
            //Blob 表示的不一定是JavaScript原生格式的数据。
            //File 接口基于Blob，继承了 blob 的功能并将其扩展使其支持用户系统上的文件。
            //返回一个新创建的 Blob 对象，其内容由参数中给定的数组串联组成。
            new Blob([wbout], {
              type: 'application/octet-stream'
            }),
            //设置导出文件名称
            '考试列表.xlsx'
          )
        } catch (e) {
          if (typeof console !== 'undefined') console.log(e, wbout)
        }
        return wbout
      }

    },
    filters: {
      transfermDate(val) {
        if (val == null) return val
        return val.split('T')[0]
      },
      transfermExamFile(val) {
        if (val == null) return val
        if (val == "0") return "手动归档"
        else return "自动归档"
      },
      transfermAssignTopic(val) {
        if (val == null) return val
        if (val == "1") return "固定"
        else return "随机"
      },
      transfermFractionType(val) {
        if (val == null) return val
        if (val == "1") return "使用题库试题分数"
        else return "指定题型分数"
      },
      transfermAchievementType(val) {
        if (val == null) return val
        if (val == "1") return "考试结束后"
        if (val == "2") return "指定时间"
        else return "不公示"
      }
    }

  }
</script>

<style>
</style>
