<template>
    <div class="#app">
        <h2> Welecome to net work </h2>
    </div>

</template>

<style lang="less" scoped>

</style>

<script>
export default {
    
}
</script>