<template>
    <div id="app">
        <h2>我是错题区</h2>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="less" scoped>

</style>