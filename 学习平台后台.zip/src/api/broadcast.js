import Vue from 'vue'
var BroadCast = new Vue()
export default BroadCast
