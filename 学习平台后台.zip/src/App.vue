<template>
  <div id="app">
    <!-- 路由占位符 通过路由匹配到的组件都会显示在router-view里展示 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
</style>
